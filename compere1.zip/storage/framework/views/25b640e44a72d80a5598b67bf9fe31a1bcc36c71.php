<div class="col-lg-12 col-md-12 dropdown-menu show" aria-labelledby="dropdownMenuLink">
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a class="dropdown-item" href="#"><?php echo e($datas->term); ?></a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
<?php /**PATH /Users/admin/mywww/compare_app/resources/views/sugest.blade.php ENDPATH**/ ?>